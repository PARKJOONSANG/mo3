package com.skt.pe.sample;

import android.app.Activity;

public class MemberEditTextActivity extends Activity {
	MemberEditText mstv = null;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
	    setContentView(R.layout.membersearchtextview);
	    
	    mstv = (MemberEditText) findViewById(R.id.membersearchtextview_textview1);
	    mstv.addText("이상래", "pluto248");
	    mstv.addText("김필종", "pbell");
	    
	    Button printLog = (Button) findViewById(R.id.membersearchtextview_button1);
	    printLog.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				DebugLog(mstv.getNames());
			    DebugLog(mstv.getValues());
			}
	    	
	    });
	    
	}
	
	private void DebugLog(String[] data) {
		for (int i=0; i<data.length; i++) {
			Log.d("TEST", data[i]);
		}
	}
}
