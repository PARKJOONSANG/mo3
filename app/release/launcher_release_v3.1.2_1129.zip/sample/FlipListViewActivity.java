
public class TweetListActivity extends TweetCommonActivity implements AdapterView.OnItemClickListener, OnFlipListener, CommonUI {
	private FlipListView mFilpistView = null;
	private TweetListPrimitive mTlPrim = null;
	private TweetAdapter mTweetAdapter = null;
	private final static String BACKGROUD_WHAT = "WHAT";
	
	@Override
	protected int assignLayout() {
		return R.layout.list;
	}
	
	@Override
	protected void onCreateX(Bundle savedInstanceState) {
		super.onCreateX(savedInstanceState);
		Intent intent = getIntent();
		
		initUI();
		
		mTlPrim = new TweetListPrimitive();
		mTlPrim.setPage(1);
		if (getTweetActivityInfo().getUserSeq() != null) {
			mTlPrim.setUserSeq(getTweetActivityInfo().getUserSeq());
		}
		mTlPrim.setListType(listType);
		
		executePrimitive(mTlPrim);
	}
	
	@Override
	protected void onResumeX() {
		SKTUtil.log("TEST", "TweetListActivity Resume: ");
	}
	
	@Override
	public void onDestroy() {
		if (refreshReceiver != null)
			unregisterReceiver(refreshReceiver);
		super.onDestroy();
	}
	
	@Override
	protected void onReceive(Primitive primitive, SKTException e) {
		super.onReceive(primitive, e);	
		if (e == null) {
			if (primitive instanceof TweetListPrimitive) {
				TweetListPrimitive tlPrim = (TweetListPrimitive) primitive;
				Integer what = (Integer) tlPrim.getTag(BACKGROUD_WHAT);
				if (what != null) {
					switch (what.intValue()) {
						case FlipListViewHelper.Event.FOOTER:
							break;
						case FlipListViewHelper.Event.HEADER:
							break;
					}
				}
				/*
				 * 첫페이지를 요청하면 List를 초기화한 후 다시 로딩한다. (Refresh)
				 */
				if (tlPrim.getPage() == 1) {
					clearAdapter();
				}
				addAdapter(tlPrim);
				if (what != null) {
					mFilpistView.done(what.intValue());
				}
			}
		} else {
			if (primitive instanceof TweetListPrimitive) {
				TweetListPrimitive tlPrim = (TweetListPrimitive) primitive;
				Integer what = (Integer) tlPrim.getTag(BACKGROUD_WHAT);
				if (what != null) {
					mFilpistView.done(what.intValue());
				}
			}
			e.alert(this, new DialogButton(0) {
				public void onClick(DialogInterface dialog, int which) {
					
				}
			});
		}
	}
	
	@Override
	public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
		super.launchTweetDetail(this.mTweetAdapter.getItem(position-1));
	}
	
	/*
	 * 사용자가 Refresh 액션을 취했을 때...  이때는 백그라운드로 요청을 한다.
	 */
	@Override
	public void onRefresh(int what) {
		mTlPrim.setPage(1);
		mTlPrim.setTag(BACKGROUD_WHAT, new Integer(what));
		executePrimitiveBg(mTlPrim);
	}
	
	@Override
	public void onMoreItem(int what) {
		mTlPrim.setPage(mTlPrim.getPage() + 1);
		mTlPrim.setTag(BACKGROUD_WHAT, new Integer(what));
		executePrimitiveBg(mTlPrim);
	}

	@Override
	public void initUI() {
		mFilpistView = (FlipListView) findViewById(R.id.list_listview_main);
		mTweetAdapter = new TweetAdapter(this, R.layout.list_listview_item);
		
		int [] headerIds = {
				R.layout.common_flip_status, R.id.common_flip_status_textview, R.id.common_flip_status_imageview,
				R.drawable.icon_update02, R.drawable.icon_update01
		};
		
		int [] footerIds = {
				R.layout.common_flip_status, R.id.common_flip_status_textview, R.id.common_flip_status_imageview
		};
		
		mFilpistView.init(60, headerIds, footerIds, R.anim.progress_anim);
		mFilpistView.setOnFlipListener(this);
        
		mFilpistView.setAdapter(mTweetAdapter);
		mFilpistView.setOnItemClickListener(this);
	}

	@Override
	public void resetUI() {
		
	}

	@Override
	public String validationUI() {
		return null;
	}
	
	private void clearAdapter() {
		mTweetAdapter.clear();
	}
	
	private void addAdapter(TweetListPrimitive tweetPrim) {
		mFilpistView.setPageInfo(tweetPrim.getPage(), tweetPrim.getEnd());
		mFilpistView.setMaxItem(tweetPrim.getTweetList().size());
		
		List<Tweet> tweetList = tweetPrim.getTweetList();
		
		for (int i=0; i<tweetList.size(); i++) {
			mTweetAdapter.add(tweetList.get(i));
		}

		mTweetAdapter.notifyDataSetChanged();
	}
}
